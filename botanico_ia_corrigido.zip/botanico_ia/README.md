# Botânico IA — versão inicial 0.1.1

Projeto Flutter Android independente, com interface em português e identificação de plantas por imagem usando a API oficial Pl@ntNet.

## O que já está preparado

- Tela inicial Botânico IA.
- Seleção de foto pela câmera ou galeria.
- Envio da imagem ao Worker Cloudflare.
- Endereço do Worker já configurado no aplicativo: `https://botanico-ia.ybourne40.workers.dev`.
- Leitura do resultado da Pl@ntNet tanto quando o Worker devolve o JSON diretamente quanto quando devolve o objeto `identification`.
- Fluxo do GitHub Actions para gerar o APK Android automaticamente.

## Segurança

A chave privada da Pl@ntNet deve ficar somente no Cloudflare Worker, cadastrada como Secret com o nome `PLANTNET_API_KEY`. Não coloque a chave no aplicativo, no GitHub ou neste projeto. O endereço do Worker não é uma senha.

## Gerar o APK pelo GitHub

1. Crie um repositório novo no GitHub chamado `botanico-ia`.
2. Envie para ele todos os arquivos e pastas que estão dentro desta pasta `botanico_ia` (incluindo a pasta oculta `.github`).
3. No GitHub, abra a aba **Actions**. Se necessário, habilite os workflows.
4. O workflow **Gerar APK Android** será executado após o envio dos arquivos. Também pode ser iniciado em **Actions > Gerar APK Android > Run workflow**.
5. Quando terminar, abra a execução concluída e baixe o artefato **botanico-ia-apk**. Dentro dele estará `app-release.apk`.
6. Abra o APK no Android para instalar. Talvez seja necessário autorizar a instalação de aplicativos dessa origem.

## Teste do servidor

O Worker está configurado em `https://botanico-ia.ybourne40.workers.dev`. A rota `/health` confirma que o servidor está ativo. A identificação usa `POST /identify` com uma imagem no campo multipart `image`.

## Observações

- A Pl@ntNet identifica espécies; não oferece diagnóstico completo de doenças para todas as plantas.
- A pontuação é uma correspondência do modelo, não uma garantia de identificação.
- Não use a identificação como única base para consumo, uso medicinal ou segurança de crianças e animais.
- Antes de divulgar o aplicativo publicamente, implemente limites de uso e proteção contra abuso no Worker.
