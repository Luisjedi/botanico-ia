// Cloudflare Worker: mantém a chave privada do Pl@ntNet fora do aplicativo Android.
// Configure PLANTNET_API_KEY como secret no painel do Cloudflare.
export default {
  async fetch(request, env) {
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors });
    const url = new URL(request.url);
    if (request.method !== 'POST' || url.pathname !== '/identify') {
      return Response.json({ error: 'Rota não encontrada.' }, { status: 404, headers: cors });
    }
    if (!env.PLANTNET_API_KEY) {
      return Response.json({ error: 'Chave Pl@ntNet não configurada no servidor.' }, { status: 503, headers: cors });
    }
    try {
      const incoming = await request.formData();
      const image = incoming.get('image');
      if (!(image instanceof File)) {
        return Response.json({ error: 'Envie uma imagem no campo image.' }, { status: 400, headers: cors });
      }
      const form = new FormData();
      form.append('images', image, image.name || 'plant.jpg');
      form.append('organs', 'auto');
      const api = await fetch(`https://my-api.plantnet.org/v2/identify/all?api-key=${encodeURIComponent(env.PLANTNET_API_KEY)}&lang=pt`, {
        method: 'POST', body: form,
      });
      const body = await api.text();
      return new Response(body, { status: api.status, headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8' } });
    } catch (error) {
      return Response.json({ error: 'Erro ao processar a imagem.' }, { status: 500, headers: cors });
    }
  },
};
